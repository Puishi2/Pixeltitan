package de.Puishi.TitanJump.gamestate;

public enum GameState {

    LOBBY,
    STARTING,
    INGAME,
    SHOPPING,
    DEATHMATCHCOUNTDOWN,
    DEATHMATCH,
    ENDING;

}
